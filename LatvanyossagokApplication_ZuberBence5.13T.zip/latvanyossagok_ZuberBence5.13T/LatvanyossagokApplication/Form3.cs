﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LatvanyossagokApplication
{
    
    public partial class Form3 : Form
    {
        MySqlConnection conn;
        varosok varos;
        public Form3()
        {

            InitializeComponent();
            conn = new MySqlConnection("Server=localhost;Port=3306;Database=latvanyossagokdb;Uid=root;");
            conn.Open();
        }

        internal varosok Varos { get => varos; set => varos = value; }

        private void btn_modosit_Click(object sender, EventArgs e)
        {
            

                Form1 f1 = new Form1();
                if (string.IsNullOrWhiteSpace(tbNev.Text) || string.IsNullOrWhiteSpace(nudlakossag.Text))
                {
                    return;
                }
                var cmd = conn.CreateCommand();
                cmd.CommandText = @"UPDATE varosok SET nev = @nev, lakossag = @lakossag WHERE id = @id";



                cmd.Parameters.AddWithValue("@nev", tbNev.Text);
                cmd.Parameters.AddWithValue("@lakossag", nudlakossag.Value);
                cmd.Parameters.AddWithValue("@id", varos.Id);

                cmd.ExecuteNonQuery();
                this.Close();
            
        }
    }
}

﻿using MySql.Data.MySqlClient;
using System;
using System.Windows.Forms;

namespace LatvanyossagokApplication
{
    public partial class Form2 : Form
    {
        MySqlConnection conn;
        latvanyossagok latvanyossagok;
        public Form2()
        {
            conn = new MySqlConnection("Server=localhost;Port=3306;Database=latvanyossagokdb;Uid=root;");
            InitializeComponent();
            conn.Open();
            
        }

        internal latvanyossagok Latvanyossagok { get => latvanyossagok; set => latvanyossagok = value; }

        private void btn_modosit_Click(object sender, EventArgs e)
        {
            
            Form1 f1 = new Form1();
            if (string.IsNullOrWhiteSpace(tbnev.Text) || string.IsNullOrWhiteSpace(tbleiras.Text) || string.IsNullOrWhiteSpace(nudar.Text))
            {
                return;
            }
            var cmd = conn.CreateCommand();
            cmd.CommandText = @"UPDATE latvanyossagok SET nev = @nev, leiras = @leiras, ar = @ar WHERE id = @id";

            

            cmd.Parameters.AddWithValue("@nev", tbnev.Text);
            cmd.Parameters.AddWithValue("@leiras", tbleiras.Text);
            cmd.Parameters.AddWithValue("@ar", nudar.Value);
            cmd.Parameters.AddWithValue("@id", latvanyossagok.Id);

            cmd.ExecuteNonQuery();
            this.Close();
        }
    }
}

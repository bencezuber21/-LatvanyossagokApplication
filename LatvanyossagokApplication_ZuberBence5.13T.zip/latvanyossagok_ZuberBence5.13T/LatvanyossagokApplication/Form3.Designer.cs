﻿namespace LatvanyossagokApplication
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblnev = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tbNev = new System.Windows.Forms.TextBox();
            this.nudlakossag = new System.Windows.Forms.NumericUpDown();
            this.btn_modosit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.nudlakossag)).BeginInit();
            this.SuspendLayout();
            // 
            // lblnev
            // 
            this.lblnev.AutoSize = true;
            this.lblnev.Location = new System.Drawing.Point(353, 85);
            this.lblnev.Name = "lblnev";
            this.lblnev.Size = new System.Drawing.Size(27, 13);
            this.lblnev.TabIndex = 0;
            this.lblnev.Text = "Név";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(353, 124);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Lakosság";
            // 
            // tbNev
            // 
            this.tbNev.Location = new System.Drawing.Point(323, 101);
            this.tbNev.Name = "tbNev";
            this.tbNev.Size = new System.Drawing.Size(100, 20);
            this.tbNev.TabIndex = 2;
            // 
            // nudlakossag
            // 
            this.nudlakossag.Location = new System.Drawing.Point(323, 140);
            this.nudlakossag.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.nudlakossag.Name = "nudlakossag";
            this.nudlakossag.Size = new System.Drawing.Size(120, 20);
            this.nudlakossag.TabIndex = 3;
            // 
            // btn_modosit
            // 
            this.btn_modosit.Location = new System.Drawing.Point(331, 196);
            this.btn_modosit.Name = "btn_modosit";
            this.btn_modosit.Size = new System.Drawing.Size(75, 23);
            this.btn_modosit.TabIndex = 4;
            this.btn_modosit.Text = "Módosítás";
            this.btn_modosit.UseVisualStyleBackColor = true;
            this.btn_modosit.Click += new System.EventHandler(this.btn_modosit_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_modosit);
            this.Controls.Add(this.nudlakossag);
            this.Controls.Add(this.tbNev);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblnev);
            this.Name = "Form3";
            this.Text = "Form3";
            ((System.ComponentModel.ISupportInitialize)(this.nudlakossag)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblnev;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbNev;
        private System.Windows.Forms.NumericUpDown nudlakossag;
        private System.Windows.Forms.Button btn_modosit;
        public string SetNev
        {
            get { return tbNev.Text; }
            set { tbNev.Text = value; }
        }
        public decimal Setlakossag
        {
            get { return nudlakossag.Value; }
            set { nudlakossag.Value = value; }
        }
    }
}
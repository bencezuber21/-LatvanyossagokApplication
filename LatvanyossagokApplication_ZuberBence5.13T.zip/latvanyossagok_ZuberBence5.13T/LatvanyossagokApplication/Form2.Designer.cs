﻿using System.Windows.Forms;

namespace LatvanyossagokApplication
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbnev = new System.Windows.Forms.TextBox();
            this.tbleiras = new System.Windows.Forms.TextBox();
            this.nudar = new System.Windows.Forms.NumericUpDown();
            this.btn_modosit = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.nudar)).BeginInit();
            this.SuspendLayout();
            // 
            // tbnev
            // 
            this.tbnev.Location = new System.Drawing.Point(347, 69);
            this.tbnev.Name = "tbnev";
            this.tbnev.Size = new System.Drawing.Size(100, 20);
            this.tbnev.TabIndex = 0;
            // 
            // tbleiras
            // 
            this.tbleiras.Location = new System.Drawing.Point(347, 113);
            this.tbleiras.Name = "tbleiras";
            this.tbleiras.Size = new System.Drawing.Size(100, 20);
            this.tbleiras.TabIndex = 1;
            // 
            // nudar
            // 
            this.nudar.Location = new System.Drawing.Point(347, 156);
            this.nudar.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.nudar.Name = "nudar";
            this.nudar.Size = new System.Drawing.Size(120, 20);
            this.nudar.TabIndex = 2;
            // 
            // btn_modosit
            // 
            this.btn_modosit.Location = new System.Drawing.Point(347, 193);
            this.btn_modosit.Name = "btn_modosit";
            this.btn_modosit.Size = new System.Drawing.Size(75, 23);
            this.btn_modosit.TabIndex = 3;
            this.btn_modosit.Text = "Módosítás";
            this.btn_modosit.UseVisualStyleBackColor = true;
            this.btn_modosit.Click += new System.EventHandler(this.btn_modosit_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(344, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(27, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Név";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(344, 97);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Leírás";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(344, 140);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(17, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Ár";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_modosit);
            this.Controls.Add(this.nudar);
            this.Controls.Add(this.tbleiras);
            this.Controls.Add(this.tbnev);
            this.Name = "Form2";
            this.Text = "Form2";
            ((System.ComponentModel.ISupportInitialize)(this.nudar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbnev;
        private System.Windows.Forms.TextBox tbleiras;
        private System.Windows.Forms.NumericUpDown nudar;
        private System.Windows.Forms.Button btn_modosit;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;

        public string Setnev
        {
            get { return tbnev.Text; }
            set { tbnev.Text = value; }
        }
        public string Setleiras
        {
            get { return tbleiras.Text; }
            set { tbleiras.Text = value; }
        }
        public decimal Setar
        {
            get { return nudar.Value; }
            set { nudar.Value = value; }
        }
    }
}

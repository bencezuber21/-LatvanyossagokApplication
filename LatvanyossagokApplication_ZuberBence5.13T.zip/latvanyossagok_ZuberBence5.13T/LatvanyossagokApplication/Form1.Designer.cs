﻿using System.Windows.Forms;

namespace LatvanyossagokApplication
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_varos_nev = new System.Windows.Forms.TextBox();
            this.lb_varos = new System.Windows.Forms.Label();
            this.lb_varos_nev = new System.Windows.Forms.Label();
            this.lb_varos_lakossag = new System.Windows.Forms.Label();
            this.tb_latvanyossag_nev = new System.Windows.Forms.TextBox();
            this.tb_latvanyossag_leiras = new System.Windows.Forms.TextBox();
            this.lb_latvanyossag = new System.Windows.Forms.Label();
            this.lb_latvanyossag_nev = new System.Windows.Forms.Label();
            this.lb_latvanyossag_leiras = new System.Windows.Forms.Label();
            this.lb_latvanyossag_ar = new System.Windows.Forms.Label();
            this.btn_varos_hozzaad = new System.Windows.Forms.Button();
            this.btn_latvanyossag_hozzaad = new System.Windows.Forms.Button();
            this.nUD_varos_lakossag = new System.Windows.Forms.NumericUpDown();
            this.nUD_latvanyossag_ar = new System.Windows.Forms.NumericUpDown();
            this.listVaros = new System.Windows.Forms.ListBox();
            this.listLatvanyossag = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_latvanyossag_torles = new System.Windows.Forms.Button();
            this.btn_varos_torles = new System.Windows.Forms.Button();
            this.btn_latvanyossag_modositas = new System.Windows.Forms.Button();
            this.btn_varos_modositas = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.nUD_varos_lakossag)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nUD_latvanyossag_ar)).BeginInit();
            this.SuspendLayout();
            // 
            // tb_varos_nev
            // 
            this.tb_varos_nev.Location = new System.Drawing.Point(12, 54);
            this.tb_varos_nev.Name = "tb_varos_nev";
            this.tb_varos_nev.Size = new System.Drawing.Size(100, 20);
            this.tb_varos_nev.TabIndex = 1;
            // 
            // lb_varos
            // 
            this.lb_varos.AutoSize = true;
            this.lb_varos.Location = new System.Drawing.Point(13, 13);
            this.lb_varos.Name = "lb_varos";
            this.lb_varos.Size = new System.Drawing.Size(94, 13);
            this.lb_varos.TabIndex = 3;
            this.lb_varos.Text = "Város hozzáadása";
            // 
            // lb_varos_nev
            // 
            this.lb_varos_nev.AutoSize = true;
            this.lb_varos_nev.Location = new System.Drawing.Point(13, 38);
            this.lb_varos_nev.Name = "lb_varos_nev";
            this.lb_varos_nev.Size = new System.Drawing.Size(27, 13);
            this.lb_varos_nev.TabIndex = 5;
            this.lb_varos_nev.Text = "Név";
            // 
            // lb_varos_lakossag
            // 
            this.lb_varos_lakossag.AutoSize = true;
            this.lb_varos_lakossag.Location = new System.Drawing.Point(13, 77);
            this.lb_varos_lakossag.Name = "lb_varos_lakossag";
            this.lb_varos_lakossag.Size = new System.Drawing.Size(53, 13);
            this.lb_varos_lakossag.TabIndex = 6;
            this.lb_varos_lakossag.Text = "Lakosság";
            // 
            // tb_latvanyossag_nev
            // 
            this.tb_latvanyossag_nev.Location = new System.Drawing.Point(163, 54);
            this.tb_latvanyossag_nev.Name = "tb_latvanyossag_nev";
            this.tb_latvanyossag_nev.Size = new System.Drawing.Size(100, 20);
            this.tb_latvanyossag_nev.TabIndex = 7;
            // 
            // tb_latvanyossag_leiras
            // 
            this.tb_latvanyossag_leiras.Location = new System.Drawing.Point(163, 93);
            this.tb_latvanyossag_leiras.Name = "tb_latvanyossag_leiras";
            this.tb_latvanyossag_leiras.Size = new System.Drawing.Size(100, 20);
            this.tb_latvanyossag_leiras.TabIndex = 8;
            // 
            // lb_latvanyossag
            // 
            this.lb_latvanyossag.AutoSize = true;
            this.lb_latvanyossag.Location = new System.Drawing.Point(160, 13);
            this.lb_latvanyossag.Name = "lb_latvanyossag";
            this.lb_latvanyossag.Size = new System.Drawing.Size(133, 13);
            this.lb_latvanyossag.TabIndex = 10;
            this.lb_latvanyossag.Text = "Látványosság hozzáadása";
            // 
            // lb_latvanyossag_nev
            // 
            this.lb_latvanyossag_nev.AutoSize = true;
            this.lb_latvanyossag_nev.Location = new System.Drawing.Point(160, 38);
            this.lb_latvanyossag_nev.Name = "lb_latvanyossag_nev";
            this.lb_latvanyossag_nev.Size = new System.Drawing.Size(27, 13);
            this.lb_latvanyossag_nev.TabIndex = 11;
            this.lb_latvanyossag_nev.Text = "Név";
            // 
            // lb_latvanyossag_leiras
            // 
            this.lb_latvanyossag_leiras.AutoSize = true;
            this.lb_latvanyossag_leiras.Location = new System.Drawing.Point(160, 77);
            this.lb_latvanyossag_leiras.Name = "lb_latvanyossag_leiras";
            this.lb_latvanyossag_leiras.Size = new System.Drawing.Size(37, 13);
            this.lb_latvanyossag_leiras.TabIndex = 12;
            this.lb_latvanyossag_leiras.Text = "Leírás";
            // 
            // lb_latvanyossag_ar
            // 
            this.lb_latvanyossag_ar.AutoSize = true;
            this.lb_latvanyossag_ar.Location = new System.Drawing.Point(160, 114);
            this.lb_latvanyossag_ar.Name = "lb_latvanyossag_ar";
            this.lb_latvanyossag_ar.Size = new System.Drawing.Size(17, 13);
            this.lb_latvanyossag_ar.TabIndex = 13;
            this.lb_latvanyossag_ar.Text = "Ár";
            // 
            // btn_varos_hozzaad
            // 
            this.btn_varos_hozzaad.Location = new System.Drawing.Point(12, 141);
            this.btn_varos_hozzaad.Name = "btn_varos_hozzaad";
            this.btn_varos_hozzaad.Size = new System.Drawing.Size(75, 23);
            this.btn_varos_hozzaad.TabIndex = 14;
            this.btn_varos_hozzaad.Text = "Hozzáad";
            this.btn_varos_hozzaad.UseVisualStyleBackColor = true;
            this.btn_varos_hozzaad.Click += new System.EventHandler(this.btn_varos_hozzaad_Click);
            // 
            // btn_latvanyossag_hozzaad
            // 
            this.btn_latvanyossag_hozzaad.Location = new System.Drawing.Point(163, 176);
            this.btn_latvanyossag_hozzaad.Name = "btn_latvanyossag_hozzaad";
            this.btn_latvanyossag_hozzaad.Size = new System.Drawing.Size(75, 23);
            this.btn_latvanyossag_hozzaad.TabIndex = 15;
            this.btn_latvanyossag_hozzaad.Text = "Hozzáad";
            this.btn_latvanyossag_hozzaad.UseVisualStyleBackColor = true;
            this.btn_latvanyossag_hozzaad.Click += new System.EventHandler(this.btn_latvanyossag_hozzaad_Click);
            // 
            // nUD_varos_lakossag
            // 
            this.nUD_varos_lakossag.Location = new System.Drawing.Point(12, 94);
            this.nUD_varos_lakossag.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.nUD_varos_lakossag.Name = "nUD_varos_lakossag";
            this.nUD_varos_lakossag.Size = new System.Drawing.Size(120, 20);
            this.nUD_varos_lakossag.TabIndex = 18;
            // 
            // nUD_latvanyossag_ar
            // 
            this.nUD_latvanyossag_ar.Location = new System.Drawing.Point(163, 130);
            this.nUD_latvanyossag_ar.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.nUD_latvanyossag_ar.Name = "nUD_latvanyossag_ar";
            this.nUD_latvanyossag_ar.Size = new System.Drawing.Size(120, 20);
            this.nUD_latvanyossag_ar.TabIndex = 19;
            // 
            // listVaros
            // 
            this.listVaros.FormattingEnabled = true;
            this.listVaros.Location = new System.Drawing.Point(394, 32);
            this.listVaros.Name = "listVaros";
            this.listVaros.Size = new System.Drawing.Size(181, 95);
            this.listVaros.TabIndex = 20;
            this.listVaros.SelectedIndexChanged += new System.EventHandler(this.listVaros_SelectedIndexChanged);
            // 
            // listLatvanyossag
            // 
            this.listLatvanyossag.FormattingEnabled = true;
            this.listLatvanyossag.Location = new System.Drawing.Point(394, 162);
            this.listLatvanyossag.Name = "listLatvanyossag";
            this.listLatvanyossag.Size = new System.Drawing.Size(181, 95);
            this.listLatvanyossag.TabIndex = 21;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(391, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 13);
            this.label1.TabIndex = 22;
            this.label1.Text = "Városok";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label2.Location = new System.Drawing.Point(391, 141);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 13);
            this.label2.TabIndex = 23;
            this.label2.Text = "Látványosságok";
            // 
            // btn_latvanyossag_torles
            // 
            this.btn_latvanyossag_torles.Location = new System.Drawing.Point(581, 162);
            this.btn_latvanyossag_torles.Name = "btn_latvanyossag_torles";
            this.btn_latvanyossag_torles.Size = new System.Drawing.Size(75, 23);
            this.btn_latvanyossag_torles.TabIndex = 24;
            this.btn_latvanyossag_torles.Text = "Törlés";
            this.btn_latvanyossag_torles.UseVisualStyleBackColor = true;
            this.btn_latvanyossag_torles.Click += new System.EventHandler(this.btn_latvanyossag_torles_Click);
            // 
            // btn_varos_torles
            // 
            this.btn_varos_torles.Location = new System.Drawing.Point(581, 38);
            this.btn_varos_torles.Name = "btn_varos_torles";
            this.btn_varos_torles.Size = new System.Drawing.Size(75, 23);
            this.btn_varos_torles.TabIndex = 25;
            this.btn_varos_torles.Text = "Törlés";
            this.btn_varos_torles.UseVisualStyleBackColor = true;
            this.btn_varos_torles.Click += new System.EventHandler(this.btn_varos_torles_Click);
            // 
            // btn_latvanyossag_modositas
            // 
            this.btn_latvanyossag_modositas.Location = new System.Drawing.Point(581, 204);
            this.btn_latvanyossag_modositas.Name = "btn_latvanyossag_modositas";
            this.btn_latvanyossag_modositas.Size = new System.Drawing.Size(75, 23);
            this.btn_latvanyossag_modositas.TabIndex = 26;
            this.btn_latvanyossag_modositas.Text = "Módosítás";
            this.btn_latvanyossag_modositas.UseVisualStyleBackColor = true;
            this.btn_latvanyossag_modositas.Click += new System.EventHandler(this.btn_latvanyossag_modositas_Click);
            // 
            // btn_varos_modositas
            // 
            this.btn_varos_modositas.Location = new System.Drawing.Point(581, 77);
            this.btn_varos_modositas.Name = "btn_varos_modositas";
            this.btn_varos_modositas.Size = new System.Drawing.Size(75, 23);
            this.btn_varos_modositas.TabIndex = 27;
            this.btn_varos_modositas.Text = "Módosítás";
            this.btn_varos_modositas.UseVisualStyleBackColor = true;
            this.btn_varos_modositas.Click += new System.EventHandler(this.btn_varos_modositas_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_varos_modositas);
            this.Controls.Add(this.btn_latvanyossag_modositas);
            this.Controls.Add(this.btn_varos_torles);
            this.Controls.Add(this.btn_latvanyossag_torles);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listLatvanyossag);
            this.Controls.Add(this.listVaros);
            this.Controls.Add(this.nUD_latvanyossag_ar);
            this.Controls.Add(this.nUD_varos_lakossag);
            this.Controls.Add(this.btn_latvanyossag_hozzaad);
            this.Controls.Add(this.btn_varos_hozzaad);
            this.Controls.Add(this.lb_latvanyossag_ar);
            this.Controls.Add(this.lb_latvanyossag_leiras);
            this.Controls.Add(this.lb_latvanyossag_nev);
            this.Controls.Add(this.lb_latvanyossag);
            this.Controls.Add(this.tb_latvanyossag_leiras);
            this.Controls.Add(this.tb_latvanyossag_nev);
            this.Controls.Add(this.lb_varos_lakossag);
            this.Controls.Add(this.lb_varos_nev);
            this.Controls.Add(this.lb_varos);
            this.Controls.Add(this.tb_varos_nev);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.nUD_varos_lakossag)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nUD_latvanyossag_ar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tb_varos_nev;
        private System.Windows.Forms.Label lb_varos;
        private System.Windows.Forms.Label lb_varos_nev;
        private System.Windows.Forms.Label lb_varos_lakossag;
        private System.Windows.Forms.TextBox tb_latvanyossag_nev;
        private System.Windows.Forms.TextBox tb_latvanyossag_leiras;
        private System.Windows.Forms.Label lb_latvanyossag;
        private System.Windows.Forms.Label lb_latvanyossag_nev;
        private System.Windows.Forms.Label lb_latvanyossag_leiras;
        private System.Windows.Forms.Label lb_latvanyossag_ar;
        private System.Windows.Forms.Button btn_varos_hozzaad;
        private System.Windows.Forms.Button btn_latvanyossag_hozzaad;
        private System.Windows.Forms.NumericUpDown nUD_varos_lakossag;
        private System.Windows.Forms.NumericUpDown nUD_latvanyossag_ar;
        private System.Windows.Forms.ListBox listVaros;
        private System.Windows.Forms.ListBox listLatvanyossag;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_latvanyossag_torles;
        private System.Windows.Forms.Button btn_varos_torles;
        private System.Windows.Forms.Button btn_latvanyossag_modositas;
        private System.Windows.Forms.Button btn_varos_modositas;

        
    }
}


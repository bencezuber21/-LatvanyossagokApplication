﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LatvanyossagokApplication
{
    public partial class Form1 : Form
    {
        MySqlConnection conn;
        public Form1()
        {
            InitializeComponent();
            conn = new MySqlConnection("Server=localhost;Port=3306; Database = latvanyossagokdb;Uid=root;");
            conn.Open();
            createDB();
            createTables();
            varosListaz();
            
        }

        void createDB()
        {
            var cmd = conn.CreateCommand();
            cmd.CommandText = @"CREATE DATABASE IF NOT EXISTS latvanyossagokdb CHARACTER SET utf8mb4 COLLATE utf8mb4_hungarian_ci;" ;
            cmd.ExecuteNonQuery();
        }

        void createTables()
        {
            var cmd = conn.CreateCommand();
            cmd.CommandText = @"CREATE TABLE IF NOT EXISTS `varosok` (
                                  `id` int(11) NOT NULL,
                                  `nev` varchar(128) COLLATE utf8_hungarian_ci NOT NULL,
                                  `lakossag` int(11) NOT NULL
                                ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
                                INSERT INTO `varosok` (`id`, `nev`, `lakossag`) VALUES
                                (2, 'Budapest', 400);
                                CREATE TABLE IF NOT EXISTS `latvanyossagok` (
                                  `id` int(11) NOT NULL,
                                  `nev` varchar(128) COLLATE utf8_hungarian_ci NOT NULL,
                                  `leiras` varchar(512) COLLATE utf8_hungarian_ci NOT NULL,
                                  `ar` int(11) DEFAULT NULL,
                                  `varos_id` int(11) NOT NULL
                                ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;
                                ALTER TABLE `latvanyossagok`
                                  ADD PRIMARY KEY (`id`),
                                  ADD KEY `varos_id` (`varos_id`) USING BTREE;
                                ALTER TABLE `varosok`
                                  ADD PRIMARY KEY (`id`);
                                ALTER TABLE `latvanyossagok`
                                  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
                                ALTER TABLE `varosok`
                                  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
                                ALTER TABLE `latvanyossagok`
                                  ADD CONSTRAINT `latvanyossagok_ibfk_1` FOREIGN KEY (`varos_id`) REFERENCES `varosok` (`id`);
                                COMMIT;";

        }

        void varosListaz() {
            listVaros.Items.Clear();
            var command = conn.CreateCommand();
            if (listVaros.SelectedIndex == 0)
            {

            }
            command.CommandText = @"SELECT id,nev,lakossag FROM varosok ORDER BY nev";
            using (var reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    var id = reader.GetInt32("id");
                    var nev = reader.GetString("nev");
                    var lakossag = reader.GetInt32("lakossag");

                    var varos = new varosok(id, nev, lakossag);

                    listVaros.Items.Add(varos);
                }
            }
        }
        public void latvanyossagListaz() {
            listLatvanyossag.Items.Clear();
            var command = conn.CreateCommand();
            var varosok = (varosok)listVaros.SelectedItem;
            if (varosok != null)
            {
                command.CommandText = @"SELECT id,nev,leiras,ar,varos_id FROM latvanyossagok
                                                    WHERE varos_id = " + varosok.Id;
                using (var reader = command.ExecuteReader())
                            {
                                while (reader.Read())
                                {
                                    var id = reader.GetInt32("id");
                                    var nev = reader.GetString("nev");
                                    var leiras = reader.GetString("leiras");
                                    var ar= reader.GetInt32("ar");
                                    var varos_id = reader.GetInt32("varos_id");
                                    var latvanyossag = new latvanyossagok(id, nev, leiras, ar, varos_id);
                                    
                                    listLatvanyossag.Items.Add(latvanyossag);
                                }
                            }
            }
                
            
            
        }

        private void btn_varos_hozzaad_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tb_varos_nev.Text) || string.IsNullOrWhiteSpace(nUD_varos_lakossag.Text))
            {
                MessageBox.Show("Minden mezőt ki kell tölteni");
                return;
            }

            var cmd = conn.CreateCommand();
            cmd.CommandText = @"INSERT INTO varosok(nev,lakossag)
                                VALUES(@nev,@lakossag)";
            cmd.Parameters.AddWithValue("@nev", tb_varos_nev.Text);
            cmd.Parameters.AddWithValue("@lakossag", nUD_varos_lakossag.Value);

            cmd.ExecuteNonQuery();

            varosListaz();
        }

        private void btn_latvanyossag_hozzaad_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tb_latvanyossag_nev.Text) || string.IsNullOrWhiteSpace(tb_latvanyossag_leiras.Text) || string.IsNullOrWhiteSpace(nUD_latvanyossag_ar.Text) ||listVaros.SelectedItem == null )
            {
                MessageBox.Show("Minden mezőt ki kell tölteni!");
                return;
            }
            var cmd = conn.CreateCommand();
            
            var varosok = (varosok)listVaros.SelectedItem;
            

            cmd.CommandText = @"INSERT INTO latvanyossagok(nev,leiras,ar,varos_id)
                                VALUES(@nev,@leiras,@ar,@varos_id)";
            cmd.Parameters.AddWithValue("@nev", tb_latvanyossag_nev.Text);
            cmd.Parameters.AddWithValue("@leiras", tb_latvanyossag_leiras.Text);
            cmd.Parameters.AddWithValue("@ar", nUD_latvanyossag_ar.Value);
            cmd.Parameters.AddWithValue("@varos_id", varosok.Id);

            cmd.ExecuteNonQuery();

            latvanyossagListaz();
        }

        private void listVaros_SelectedIndexChanged(object sender, EventArgs e)
        {
            var varosok = (varosok)listVaros.SelectedItem;
            latvanyossagListaz();
        }

        private void btn_varos_torles_Click(object sender, EventArgs e)
        {
            if (listVaros.SelectedIndex == -1)
            {
                MessageBox.Show("Válasszon ki egy elemet a törléshez");
                return;
            }
            clearLatvanyossag();

            var cmd = conn.CreateCommand();
            cmd.CommandText = @"DELETE FROM varosok WHERE id = @id";

            var varos = (varosok)listVaros.SelectedItem;

            cmd.Parameters.AddWithValue("@id", varos.Id);

            cmd.ExecuteNonQuery();

            

            varosListaz();
            listLatvanyossag.Items.Clear();
        }

        private void btn_latvanyossag_torles_Click(object sender, EventArgs e)
        {
            if (listLatvanyossag.SelectedIndex == -1)
            {
                MessageBox.Show("Válasszon ki egy elemet a törléshez!");
                return;
            }

            var cmd = conn.CreateCommand();
            cmd.CommandText = @"DELETE FROM latvanyossagok WHERE id = @id";

            var latvanyossag = (latvanyossagok)listLatvanyossag.SelectedItem;

            cmd.Parameters.AddWithValue("@id", latvanyossag.Id);

            cmd.ExecuteNonQuery();

            latvanyossagListaz();
        }

        private void clearLatvanyossag() {
            var cmd = conn.CreateCommand();
            cmd.CommandText = @"DELETE FROM latvanyossagok WHERE varos_id = @id";

            var varos = (varosok)listVaros.SelectedItem;

            cmd.Parameters.AddWithValue("@id", varos.Id);

            cmd.ExecuteNonQuery();
        }
        //látv. módosítás
        private void btn_latvanyossag_modositas_Click(object Sender, EventArgs e) {
            Form2 f2 = new Form2();
            var latvanyossag = (latvanyossagok)listLatvanyossag.SelectedItem;
            f2.Latvanyossagok = (latvanyossagok)listLatvanyossag.SelectedItem;
            if (latvanyossag != null)
            {
                f2.Setnev = latvanyossag.Nev;
                f2.Setleiras = latvanyossag.Leiras;
                f2.Setar = latvanyossag.Ar;
                f2.ShowDialog();
                
            }

            latvanyossagListaz();

        }
        //város módosítás
        private void btn_varos_modositas_Click(object sender, EventArgs e)
        {
            Form3 f3 = new Form3();
            var varos = (varosok)listVaros.SelectedItem;
            f3.Varos = (varosok)listVaros.SelectedItem;
            if (varos != null)
            {
                f3.SetNev = varos.Nev;
                f3.Setlakossag = varos.Lakossag;
                f3.ShowDialog();

            }

            varosListaz();

        }
    }
    }

